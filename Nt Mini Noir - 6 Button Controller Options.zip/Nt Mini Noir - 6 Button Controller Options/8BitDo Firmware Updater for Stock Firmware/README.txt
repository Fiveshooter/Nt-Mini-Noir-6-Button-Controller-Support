Use the 8BitDo Firmware Updater if you need to reinstall the stock firmware on your 8BitDo Retro Receiver.
DO NOT use it to attempt to install the custom Analogue Nt Mini firmware.
Use the update tool provided with  the custom Analogue Nt Mini firmware to install it instead.