NOTE: The 8Bitdo N30 2.4g or Bluetooth NES receiver will NOT give the input listed below when paired
with ANY controller!! 
Using this reciever, the BEST you will get with ANY paired controller is three action buttons with 'Select' used for 'C'.
The good news is, the issue lies with the 8BitDo receiver's capabilities and NOT your Analogue Nt Mini Noir v2.

The easiest way to can get all 6 action buttons along with 'Start' & 'Select' is with an SNES controller to NES console adapter.
If using only a wired SNES controller, you can skip the information on using wireless controllers.

For wireless, you will need to use either the 2.4g or Bluetooth 8BitDo receivers specifically designed to work with original SNES hardware.
It is possible to pair an 8BitDo M30 2.4g controller with an 8BitDo 2.4g SNES receiver!
To do so, simply put the controller in pairing more and hold it no more than a couple of inches away from the receiver while blue lite is blinking on the receiver.
The 2.4g receiver does not have a pairing button but, the blue lite flashes when it is not connected to any other controller.
It may take several seconds to pair but, eventually both the flashing lights on the controller and receiver will remain solidly lit.
Once your M30 is paired to the SNES receiver, it will remain paired until you pair it with another receiver.

The Bluetooth SNES receiver versions are sold without controllers and can be paired with several other Bluetooth controllers.

Mappings you will get using a SNES controller to NES console adapter:

|  MD | SNES |
| ------ |  ----  |
| `A`   |  `B`  |
| `B`   |  `Y`  |
| `C`   |  `A`  |
| `X`   |  `X`  |
| `Y`   |  `L`  |
| `Z`   |  `R`  |

| MD | M30 |
| ----- |  ---   |
| `A`  |  `B`  |
| `B`  |  `Y`  |
| `C`  |  `A`  |
| `X`  |  `X`  |
| `Y`  |  `Z`  |
| `Z`  |  `C`  |